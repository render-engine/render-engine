import os
import typing

PathString = typing.Union[str, os.PathLike]
