from pathlib import Path
from typing import Union, Type

PathString = Union[str, Type[Path]]
