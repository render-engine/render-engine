import typing
from pathlib import Path

PathString = typing.Union[str, typing.Type[Path]]
