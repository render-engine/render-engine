from pathlib import Path
from typing

PathString = typing.Union[str, typing.Type[Path]]

